<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        @include('partials.seo-head', [
            'title' => 'QR Code Generator',
            'description' => 'Create free QR codes for URLs, Wi-Fi networks, business cards, and text. Export PNG or SVG instantly with ToolKitly.',
            'path' => '/qr-code-generator',
        ])
        @include('partials.adsense-head')
        @include('partials.analytics-head')
    </head>
    <body class="min-h-screen bg-[#f4f7f5] text-[#171411] antialiased">
        <div class="min-h-screen">
            @include('partials.navigation')
            @include('partials.ad-slot', ['slot' => 'top'])

            <div
                id="app"
                data-tool="qr-code-generator"
                data-metadata-url="{{ url('/api/tools/qr-code-generator') }}"
                data-payload-url="{{ url('/api/tools/qr-code-generator/payload') }}"
                data-initial-url="{{ url('/qr-code-generator') }}"
            ></div>
            @include('partials.related-tools')
            @include('partials.ad-slot', ['slot' => 'bottom'])
            @include('partials.footer')
        </div>
    </body>
</html>
